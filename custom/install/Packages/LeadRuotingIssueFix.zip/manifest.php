<?php
$manifest =array (
  'acceptable_sugar_versions' => 
  array (
      0 => '6.*.*.*',
  ),
  array (
    'acceptable_sugar_flavors' => 
    array (
      0 => 'CE',
      1 => 'PRO',
      2 => 'ENT',
    ),
  ),
  'author' => 'Rolustech',
  'description' => 'Fix issues for Leads automatic distribution',
  'icon' => '',
  'is_uninstallable' => 'true',
  'name' => 'issue_fix_1.0',
  'published_date' => '2018-07-23 20:20:00',
  'type' => 'module',
  'version' => '1.0',
);
$installdefs =array (
  'id' => 'issue_fix_1.0',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_fourth_assignment_time_c.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Vardefs/sugarfield_fourth_assignment_time_c.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/hooks/lead_distrib_hook.php',
      'to' => 'custom/hooks/lead_distrib_hook.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/include/ax_jobs.php',
      'to' => 'custom/include/ax_jobs.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/custom/modules/Leads/metadata/editviewdefs.php',
      'to' => 'custom/modules/Leads/metadata/editviewdefs.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/custom/ax/DistribLead.php',
      'to' => 'custom/ax/DistribLead.php',
    ),
  ),
);